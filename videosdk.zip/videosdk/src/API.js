
export const authToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcGlrZXkiOiI2MDg2ZjIyZC1hM2U5LTQ2YmItYWFkMC02NWQxMjVhMWU1NzQiLCJwZXJtaXNzaW9ucyI6WyJhbGxvd19qb2luIl0sImlhdCI6MTc1Nzc1NzQzNywiZXhwIjoxNzU4MzYyMjM3fQ.gtEEtd0cJEn1FANJA51PmiEszyY_ISKCfHIWqrC977c"

export const createMeeting = async ({ token }) => {
  const res = await fetch(`https://api.videosdk.live/v2/rooms`, {
    method: "POST",
    headers: {
      authorization: `${authToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({}),
  });
 
  const { roomId } = await res.json();
  return roomId;
};