import { useMeeting } from "@videosdk.live/react-sdk";

const Controls = ({switchMeeting}) => {
    const { leave, toggleMic, toggleWebcam } = useMeeting();
    
    return (
      <div>
        <button onClick={() => leave()}>Leave</button>
        <button onClick={() => toggleMic()}>toggleMic</button>
        <button onClick={() => toggleWebcam()}>toggleWebcam</button>
        <button onClick={switchMeeting}>Switch to Another Room</button>
      </div>
    );
}

export default Controls

