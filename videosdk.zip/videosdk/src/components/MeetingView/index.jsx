import Controls from "../Controls";
import ParticipantView from "../ParticipantView";
import { useState } from 'react'
import { useMeeting } from "@videosdk.live/react-sdk";
import { authToken, createMeeting } from "../../API";

const MeetingView = (props) => {

  const [joined, setJoined] = useState(null);

  const { join, participants, switchTo, leave } = useMeeting({
    onMeetingJoined: () => {
      setJoined("JOINED");
    },
    onMeetingLeft: () => {
      props.onMeetingLeave();
    },
  });


  const joinMeeting = () => {
    setJoined("JOINING");
    join();
  };

  const switchMeeting = async () => {
    const newMeetingId = await createMeeting({ token: authToken });
    //await leave()

    await switchTo({
      meetingId: newMeetingId,
      token: authToken,
      micEnabled: true,
      webcamEnabled: true,
      name: "Pravin Sharma",
    })
    props.setMeetingId(newMeetingId)

    //joinMeeting()
  };

  return (
    <div className="container">
      <h3>Meeting Id: {props.meetingId}</h3>
      {joined && joined == "JOINED" ? (
        <div>
          <Controls switchMeeting={switchMeeting} />
          {[...participants.keys()].map((participantId) => (
            <ParticipantView
              participantId={participantId}
              key={participantId}
            />
          ))}
        </div>
      ) : joined && joined == "JOINING" ? (
        <p>Joining the meeting...</p>
      ) : (
        <button onClick={joinMeeting}>Join</button>
      )}
    </div>
  );
}

export default MeetingView