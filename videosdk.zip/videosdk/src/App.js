import "./App.css";
import { useState } from "react";
import { MeetingProvider, useMeeting } from "@videosdk.live/react-sdk";
import { authToken, createMeeting } from "./API";
import JoinScreen from "./components/JoinScreen";
import MeetingView from "./components/MeetingView";


function App() {

  const [meetingId, setMeetingId] = useState(null);

  const getMeetingAndToken = async (id) => {
    const meetingId = id == null ? await createMeeting({ token: authToken }) : id;
    setMeetingId(meetingId);
  };

  const onMeetingLeave = () => {
    setMeetingId(null);
  };

  return authToken && meetingId ? (
    <MeetingProvider
      config={{
        meetingId,
        micEnabled: true,
        webcamEnabled: true,
        name: "Pravin Sharma",
      }}
      token={authToken}
    >
      <MeetingView meetingId={meetingId} onMeetingLeave={onMeetingLeave} setMeetingId={setMeetingId}/>
    </MeetingProvider>
  ) : (
    <JoinScreen getMeetingAndToken={getMeetingAndToken} />
  );
}

export default App;